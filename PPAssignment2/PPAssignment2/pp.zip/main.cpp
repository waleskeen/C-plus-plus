#include <iostream>
#include <omp.h>
#include <ctime>
#include <fstream>
#include <string>
#include "board.h"
#include <cstring>
#include <string>
#include <list>
#include <Windows.h>
#include <algorithm>

using namespace std;

typedef unsigned long long int UINT64;

Board board[22][22];
UINT64 NumOfValidWord;
UINT64 NumOfPosibleWord;
list<const char*> validWord;
list<string> allWord;
int numCPU;
char tileOnHand[7];
int gamePlay=0;

int numJoker;
char lettersToPlace[15];
int numberOfLetters=0;
int BestScore=0,PlayerScore=0,Bonus=0,tileUsed=0; //bonus only use when all 7 letter used.
string BestWord="";
int BestWordPosition[4]={0,0,0,0};  //start x, start y, end x, end y

class Edge;

class Word{
public:
	Word() {
		for(int i=0;i<26;i++){ 
			edge[i] = NULL; 
			is_word = false;
		}
	}
	~Word() {
		for(int i=0;i<26;i++) {
			if(edge[i]) 
				delete edge[i];
		}
	}
	string word;
	bool is_word; //if the word is valid gv it a true value
	Edge* edge[26]; //the index corresponds to the character in alphabetic order
};
class Edge{
public:
	Edge() {word=NULL;}
	~Edge() {if(word) delete word;}
	Word* word;
};

class Dictionary{
public:
	Dictionary();
	~Dictionary();
	void AddWord(char* w);
	int Search(char* w);
	int Search2(char* w);
	int checkValid(char* w);
private:
	Word* Root; //stores the pointer to Root Word
};

Dictionary::Dictionary(){
	Root = new Word();
}
Dictionary::~Dictionary(){
	delete Root;
}

// adds a word w to the dicitionary  
void Dictionary::AddWord(char* w){
	Word* node = Root;

	for(int i=0; w[i] != '\0'; i++){
		if(node->edge[w[i]-'A']){
			node = node->edge[w[i]-'A']->word;
			if(w[i+1] == '\0'){
				node->word = w;
			}
		}else{
			node->edge[w[i]-'A'] = new Edge();
			node = node->edge[w[i]-'A']->word = new Word();
			node->word.assign(w, i+1);
			if(w[i+1] == '\0'){ //if end of w, mark the node
				node->is_word=true;
			}}}
}
// removed a word w from the dictionary *ORIGINAL SEARCH FUNCTION UNUSED

// searches a word w from the dictionary and prints the description *ORIGINAL SEARCH FUNCTION
int Dictionary::Search(char* w){
	//traverse the tree and find the match
	Word* node = Root;

	for(int i=0; w[i] != '\0'; i++){
		if(node->edge[w[i]-'A']){
			node = node->edge[w[i]-'A']->word;
			if(w[i+1] == '\0' ){
				cout << w << endl;
				return 0;
			}
		}else break;
	}
	cout << w << " not found!\n";
	return -1;
}

//search and display all possible word in there MODIFIED FUNCTION WITHOUT JOKER (COMPLETE)
int Dictionary::Search2(char* w){
	//traverse the tree and find the match
	Word* node = Root;
	bool flag=true;
	const char* tmp;
	for(int i=0; w[i] != '\0'; i++){

		if(w[i]=='*')//wales
		{
			for(int dw=0;dw<26;dw++)
			{
				char letter=65+dw;				
				w[i]=letter;
				Search2(w);
			}
			break;
		}//wales

		if(node->edge[w[i]-'A']){
			node = node->edge[w[i]-'A']->word;
			if(node->is_word){ //Check if the word is valid
				if(validWord.size()>0){ //if the validWord list is not empty
					for(list<const char*>::iterator it=validWord.begin();it!=validWord.end();++it){
						if(strcmp(*it,node->word.c_str()) == 0){ //if same word match. jump out the loop
							flag=false; //found same word, set flag.
							break;
						}
					}
					if(flag){ //if no matches word in the validWord list, insert a new 1.
						#pragma omp critical (x1space)
						{
							validWord.push_back(node->word.c_str()); //insert.
							NumOfValidWord++;
							cout<< node->word<<", ";
						}
					}
					flag=true; //reset flag.
				}
				else { //if it's empty
					#pragma omp critical (x1space)
					{
						validWord.push_back(node->word.c_str());
						NumOfValidWord++;
						cout << node->word <<", ";
					}
				}
			}
			if(w[i+1]=='\0') return 0;
		} else break;
	}
	//cout << w << " not found!";
	return -1;
}

//search and display all possible word in there MODIFIED FUNCTION INCLUDE JOKER (INCOMPLETE)
int Dictionary::checkValid(char* w){
	//traverse the tree and find the match
	Word* node = Root;
	Word* tmpNode;
	for(int i=0; w[i] != '\0'; i++){

		if(node->edge[w[i]-'A']){
			node = node->edge[w[i]-'A']->word;
			if(w[i+1]=='\0')  //if the string completely compare, then return 0.
				return 0;
		}
		else break;
	}
	cout << w << " not found!\n";
	return -1;
}

Dictionary MDict;

void setBoard()
{
	for(int a=0;a<22;a++)
	{
		for(int b=0;b<22;b++)
		{
			if(a==0)
			{
				char *tmp=new (char[3]);
				board[0][b].letter=new (char[3]);
				tmp=itoa(b,tmp,10);

				board[0][b].letter=tmp;
			}
			else if(b==0)
			{
				board[a][0].letter=new (char[2]);
				board[a][0].letter[0]=96+a;
				board[a][0].letter[1]=NULL;
			}
			else if((a==1&&b==4) || (a==1&&b==11) || (a==1&&b==18) ||
				(a==4&&b==1) || (a==4&&b==7) || (a==4&&b==15) || (a==4&&b==21) ||
				(a==6&&b==10) || (a==6&&b==12) || (a==7&&b==4) || (a==7&&b==11) || (a==7&&b==18) || 
				(a==10&&b==6) || (a==10&&b==10) || (a==10&&b==12) || (a==10&&b==16) ||
				(a==11&&b==1) || (a==11&&b==7) || (a==11&&b==15) || (a==11&&b==21) ||
				(a==12&&b==6) || (a==12&&b==10) || (a==12&&b==12) || (a==12&&b==16) ||
				(a==15&&b==4) || (a==15&&b==11) || (a==15&&b==18) || (a==16&&b==10) || (a==16&&b==12) ||
				(a==18&&b==1) || (a==18&&b==7) || (a==18&&b==15) || (a==18&&b==21) ||
				(a==21&&b==4) || (a==21&&b==11) || (a==21&&b==18))
			{
				board[a][b].letter="!";
				board[a][b].bonustype='L';
				board[a][b].bonusnum=2;
			}
			else if((a==2&&b==2) || (a==2&&b==9) || (a==2&&b==13) || (a==2&&b==20) ||
				(a==3&&b==3) || (a==3&&b==10) || (a==3&&b==12) || (a==3&&b==19) ||
				(a==5&&b==5) || (a==5&&b==17) || (a==6&&b==6) || (a==6&&b==16) ||
				(a==7&&b==7) || (a==7&&b==15) || (a==8&&b==8) || (a==8&&b==14) ||
				(a==9&&b==2) || (a==9&&b==20) || (a==10&&b==3) || (a==10&&b==19) ||
				(a==12&&b==3) || (a==12&&b==19) || (a==13&&b==2) || (a==13&&b==20) ||
				(a==14&&b==8) || (a==14&&b==14) || (a==15&&b==7) || (a==15&&b==15) ||
				(a==16&&b==6) || (a==16&&b==16) || (a==17&&b==5) || (a==17&&b==17) ||
				(a==19&&b==3) || (a==19&&b==10) || (a==19&&b==12) || (a==19&&b==19) ||
				(a==20&&b==2) || (a==20&&b==9) || (a==20&&b==13) || (a==20&&b==20))
			{
				board[a][b].letter="$";
				board[a][b].bonustype='W';
				board[a][b].bonusnum=2;
			}
			else if((a==2&&b==5) || (a==2&&b==17) || 
				(a==5&&b==2) || (a==5&&b==9) || (a==5&&b==13) || (a==5&&b==20) || 
				(a==9&&b==5) || (a==9&&b==9) || (a==9&&b==13) || (a==9&&b==17) || 
				(a==13&&b==5) || (a==13&&b==9) || (a==13&&b==13) || (a==13&&b==17) || 
				(a==17&&b==2) || (a==17&&b==9) || (a==17&&b==13) || (a==17&&b==20) || 
				(a==20&&b==5) || (a==20&&b==17))
			{
				board[a][b].letter="@";
				board[a][b].bonustype='L';
				board[a][b].bonusnum=3;
			}
			else if((a==1&&b==8) || (a==1&&b==14) || (a==4&&b==4) || (a==4&&b==11) || (a==4&&b==18) || 
				(a==8&&b==1) || (a==8&&b==21) || (a==11&&b==4) || (a==11&&b==18) || (a==14&&b==1) || (a==14&&b==21) || 
				(a==18&&b==4) || (a==18&&b==11) || (a==18&&b==18) || (a==21&&b==8) || (a==21&&b==14))
			{
				board[a][b].letter="%";
				board[a][b].bonustype='W';
				board[a][b].bonusnum=3;
			}
			else if((a==3&&b==6) || (a==3&&b==16) || (a==6&&b==3) || (a==6&&b==19) ||
				(a==16&&b==3) || (a==16&&b==19) || (a==19&&b==6) || (a==19&&b==16))
			{
				board[a][b].letter="#";
				board[a][b].bonustype='L';
				board[a][b].bonusnum=4;
			}
			else if((a==1&&b==1) || (a==1&&b==21) || (a==21&&b==1) || (a==21&&b==21))
			{
				board[a][b].letter="^";
				board[a][b].bonustype='W';
				board[a][b].bonusnum=4;
			}
			else
				board[a][b].letter="-";
		}
	}
	board[0][0].letter=" ";
	// ! = Double Letter, @ = Triple Letter, # = Four letter, $ = Double Word, % = Triple Word, ^ = Four word
}

void displayBoard()
{	
	for(int a=0;a<22;a++)
	{
		for(int b=0;b<22;b++)
		{
			cout<<board[a][b].letter;
			if(a==0 || b<10)
				cout<<" ";
			else
				cout<<"  ";
		}
		cout<<endl;
	}
}

DWORD WINAPI readFile(LPVOID lpParam){
	clock_t begin, end;

	ifstream file("dictionary.txt"); //read file

	string temp_str;
	int counter = 0;
	char* writable;

	begin = clock();
	while (!file.eof())
	{
		file >> temp_str;
		//cast the string into char* type(enhance later)
		writable = new char[temp_str.size() + 1];
		copy(temp_str.begin(), temp_str.end(), writable);
		writable[temp_str.size()] = '\0';

		MDict.AddWord(writable); //add the word into trie
		delete[] writable; //free the writable(for next loop use)
		counter++;
	}
	end = clock();
	//cout<<"Time Taken: "<<(double)(end - begin) / CLOCKS_PER_SEC<<endl<<"Total word: "<<counter<<endl;

	return 0;
}

//Perform permutation and store into an array list, already sorted
void print_all_permutations(const string& s)
{
	clock_t begin, end;
	string s1 = s;
	//replace(s1.begin(), s1.end(), '*', 'Z'); //joker not yet settle. replace with 'Z' first
	sort(s1.begin(), s1.end()); 
	do {begin =clock();
	allWord.push_back(s1);
	NumOfPosibleWord++;
	} while (next_permutation(s1.begin(), s1.end()));
	end=clock();
	cout<<NumOfPosibleWord<<' '<<(double)(end - begin) / CLOCKS_PER_SEC<<endl;
}

void renew(){
	//remove the content inside validWord & possibleWord after 1 game.
	for(int x=0;x<NumOfValidWord;x++){
		validWord.clear();
	}
	for(int x=0;x<NumOfPosibleWord;x++){
		allWord.clear();
	}
	//for(int x=0;x<numofpoW;x++){
		//positionW[x].clear();
	//}
	NumOfValidWord=0;
	NumOfPosibleWord=0;
	numberOfLetters=0;
	//numofpoW=0;
}
int letterScore(char L){
	switch(L){
	case 'A': case 'E':
	case 'I': case 'O':
	case 'N': case 'R':
	case 'T': case 'L':
	case 'S': case 'U':
		return 1;
		break;

	case 'D': case 'G':
		return 2;
		break;

	case 'B': case 'C':
	case 'M': case 'P':
		return 3;
		break;

	case 'F': case 'H':
	case 'V': case 'W':
	case 'Y':
		return 4;
		break;

	case 'K':
		return 5;
		break;

	case 'J': case 'X':
		return 8;
		break;

	case 'Q': case 'Z':
		return 10;
		break;

	default:
		return 0;
		break;
	}
}
int calculateScore_firstRound(const string& word){ //only for the first round
	int wordScore=0;
	string tmp=word; //changes
	numJoker=0; //changes

	for(int a=0;a<7;a++)  //wales
	{
		if(tileOnHand[a]=='*')
			numJoker++;
	}
	if(numJoker>=1)//wales
	{
		string tmp1=word;
		string tmp2=tileOnHand;
		int cnt=0;
		while(tmp1.size()>numJoker)
		{
			for(int a=0;a<tmp1.size();a++)
			{
				if(tmp2.at(cnt)=='*')//if the position of the word is '*'
				{
					cnt++;
					break;
				}
				else if(tmp2.at(cnt)==tmp1.at(a))//if the position of the word and ans is same
				{
					tmp2.erase(cnt,1);
					tmp1.erase(a,1);
					break;
				}
				else if(a==tmp1.size()-1)
					cnt++;
			}
		}
		for(int a=0;a<numJoker;a++)
			replace(tmp.begin(), tmp.end(), tmp1.at(a), '*');
	}//wales

	for(int i=0;i<tmp.length();i++){
		wordScore+=letterScore(tmp[i]);
	}
	if(wordScore>BestScore){ //normal 2~4 letters, because cannot reach double letter point
		BestScore=wordScore;
		BestWord=word;
		if(word.length()==4) //4 letters
			BestWordPosition[0]=8;
		else if(word.length()==3) //3 letters
			BestWordPosition[0]=9;
		else //2 letters
			BestWordPosition[0]=10;
	}
	if(word.length() >= 5){ //if the score can be even higher

		//5 letters word as basic, because word length with 6 or 7 also need to calculate the same thing
		if((wordScore+letterScore(tmp[0])) > BestScore){ //if double up first letter have higher score
			BestScore=wordScore+letterScore(tmp[0]);
			BestWord=word;
			BestWordPosition[0]=7; //only need to know the start x position. cuz we only do cross for first round
		}
		if((wordScore+letterScore(tmp[4])) > BestScore){ //if double up last letter have higher score
			BestScore=wordScore+letterScore(tmp[4]);
			BestWord=word;
			BestWordPosition[0]=11;
		}
		//6 letters
		if(word.length() >= 6){
			if((wordScore+letterScore(tmp[1])) > BestScore){ //if double up second letter have higher score
				BestScore=wordScore+letterScore(tmp[1]);
				BestWord=word;
				BestWordPosition[0]=4;
			}
			if((wordScore+letterScore(tmp[5])) > BestScore){ //if double up second to last letter have higher score
				BestScore=wordScore+letterScore(tmp[5]);
				BestWord=word;
				BestWordPosition[0]=10;
			}

			//7 letters
			if(word.length() == 7){
				Bonus=50;
				if((wordScore+letterScore(tmp[0])+50) > BestScore){ //if double up first letter have higher score
					BestScore=wordScore+letterScore(tmp[0]);
					BestWord=word;
					BestWordPosition[0]=7; //only need to know the start x position. cuz we only do cross for first round
					BestScore+=Bonus;
				}
				if((wordScore+letterScore(tmp[4])+50) > BestScore){ //if double up last letter have higher score
					BestScore=wordScore+letterScore(tmp[4]);
					BestWord=word;
					BestWordPosition[0]=11;
					BestScore+=Bonus;
				}
				if((wordScore+letterScore(tmp[1])+50) > BestScore){ //if double up second letter have higher score
					BestScore=wordScore+letterScore(tmp[1]);
					BestWord=word;
					BestWordPosition[0]=6;
					BestScore+=Bonus;
				}
				if((wordScore+letterScore(tmp[5])+50) > BestScore){ //if double up second to last letter have higher score
					BestScore=wordScore+letterScore(tmp[5]);
					BestWord=word;
					BestWordPosition[0]=10;
					BestScore+=Bonus;
				}
				if((wordScore+letterScore(tmp[2])+50) > BestScore){ //if double up third letter have higher score
					BestScore=wordScore+letterScore(tmp[2]);
					BestWord=word;
					BestWordPosition[0]=5;
					BestScore+=Bonus;
				}
				if((wordScore+letterScore(tmp[6])+50) > BestScore){ //if double up the bottom third letter have higher score
					BestScore=wordScore+letterScore(tmp[6]);
					BestWord=word;
					BestWordPosition[0]=9;
					BestScore+=Bonus;
				}
			}
		}
	}
	cout<<word<<": ";
	return wordScore;
}
void firstGame(){
	//find the longest or highest score word from validWord list

	list<const char*>::iterator itV=validWord.begin();
	#pragma omp parallel for
	for(int x=0;x<NumOfValidWord;x++){
		string tmpV;
		#pragma omp critical (yspace)
		{
			tmpV=(string)*itV;
			itV++;
		}
		cout<<calculateScore_firstRound(tmpV)<<'\t';
	}
	//now we have the highest score and position, place the word into board
	int place=0;
	for(int x = BestWordPosition[0] ; x < (BestWordPosition[0]+BestWord.length()) ; x++){
		board[11][x].letter=new (char[2]);
		board[11][x].letter[0]=BestWord[place];
		board[11][x].letter[1]=NULL;
		//remove the tile used from tileOnHand
		int notFound=0;
		for(int y=0; y<7; y++){
			if(BestWord[place]==tileOnHand[y]){
				tileOnHand[y]=' ';
				notFound=0;
				break;
			}else
				notFound++;
			if(notFound==7){ //remove joker
				for(int x=0;x<7;x++)
					if(tileOnHand[x]=='*'){
						tileOnHand[x]=' ';
						notFound=0;
						cout<<"Joker removed";
					}
			}
		}
		place++;
	}
	tileUsed=place; 
	if(Bonus==0)
		PlayerScore+=(BestScore*2); //first round earn another double score.
	else{
		PlayerScore+=((BestScore-50)*2);
		PlayerScore+=50;
	}
}
void assignNewLetters(){
	for(int x=0;x<7;x++){ //copy the tile
		lettersToPlace[x]=tileOnHand[x];
		numberOfLetters++;
	}
}
void removeOldLetters(){
	for(int x=0;x<15;x++) //remove the tile
		lettersToPlace[x]=NULL;
	numberOfLetters=0;
}

void main()
{	
	SYSTEM_INFO sysinfo;
	GetSystemInfo( &sysinfo );
	numCPU = sysinfo.dwNumberOfProcessors;

	HANDLE h1=CreateThread(NULL,0,readFile,NULL,0,NULL);

	setBoard();
	displayBoard();

	cout<<"Please key in the letters on your hand: "<<endl;
	cin>>tileOnHand;

	clock_t begin, end;
	begin=clock();
	print_all_permutations(tileOnHand);

	WaitForSingleObject(h1,INFINITE);

	//compare from all permutation word
	list<string>::iterator itA=allWord.begin();
	//#pragma omp parallel for
	for(int x=0;x<NumOfPosibleWord;x++){ //according to the word in the list to compare all permutated word	
		string tmpSt;
		char* writable2=new char();
		#pragma omp critical (xspace)
		{
			tmpSt=*itA;
			itA++;
		}
		writable2 = new char[tmpSt.size() + 1];
		copy(tmpSt.begin(), tmpSt.end(), writable2);
		writable2[tmpSt.size()] = '\0';
		MDict.Search2(writable2); //search the word
		delete[] writable2; //free up variable for next loop use
	}
	//use the valid word to place in the board with highest score.

	if(strcmp(board[11][11].letter,"?")){
			firstGame();  //search highest score placement
			gamePlay++;
	}
	end=clock();
	cout<<endl;
	displayBoard();
	renew();
	cout<<"Best word and Score: "<<BestWord<<' '<<BestScore<<endl;
	cout<<"Player Score "<<PlayerScore<<endl;
	cout<<(double)(end - begin) / CLOCKS_PER_SEC<<endl;

	system("pause");
}