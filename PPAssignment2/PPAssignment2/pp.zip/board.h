#ifndef BOARD
#define BOARD
#include <cstring>

using namespace std;

class Board
{
public:
	char *letter;
	char bonustype;
	int bonusnum;
	bool operator >= (Board);
	bool operator == (Board);
	Board();
};

Board::Board()
{
	letter=new (char[2]);
	char bonustype='N';
	int bonusnum=1;
}

bool Board::operator >= (Board B2)
{
	if(strcmp(letter,B2.letter)>=0)
		return true;
	else
		return false;
}

bool Board::operator == (Board B2)
{
	if(strcmp(letter,B2.letter)==0)
		return true;
	else
		return false;
}

#endif;